import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import com.ahervias.myapplication.Usuario

val BD = "baseDatos"

class BaseDatos(contexto: Context) : SQLiteOpenHelper(contexto, BD, null, 1) {

    override fun onCreate(p0: SQLiteDatabase?) {
        var sql: String =
            "CREATE TABLE IF NOT EXISTS Usuario(id INTEGER PRIMARY KEY AUTOINCREMENT, nombre VARCHAR(250), edad INTEGER)"
        p0?.execSQL(sql)
    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {}

    fun insertarDatos(usuario: Usuario): String {
        val p0 = this.writableDatabase
        val contenedorValores = ContentValues()

        contenedorValores.put("nombre", usuario.nombre)
        contenedorValores.put("edad", usuario.edad)

        var resultado = p0.insert("Usuario", null, contenedorValores)

        if (resultado == -1L) {
            return "Inserción Fallida"
        } else {
            return "Inserción exitosa!"
        }
    }

    fun listarDatos(): MutableList<Usuario> {
        var lista: MutableList<Usuario> = ArrayList()
        val db = this.readableDatabase

        val sql = "SELECT * FROM Usuario"
        var resultado = db?.rawQuery(sql, null)

        resultado?.use { cursor ->
            if (cursor.moveToFirst()) {
                do {
                    var usu = Usuario()
                    usu.id = cursor.getInt(cursor.getColumnIndexOrThrow("id"))
                    usu.nombre = cursor.getString(cursor.getColumnIndexOrThrow("nombre"))
                    usu.edad = cursor.getInt(cursor.getColumnIndexOrThrow("edad"))

                    lista.add(usu)

                } while (cursor.moveToNext())
            }
        }

        db.close()

        return lista
    }

    fun actualizarDatos(id: String, nombre: String, edad: Int): String {
        try {
            val db = this.writableDatabase
            val contenedorValores = ContentValues()
            contenedorValores.put("nombre", nombre)
            contenedorValores.put("edad", edad)

            val resultado = db.update("Usuario", contenedorValores, "id=?", arrayOf(id))

            db.close()

            return if (resultado > 0) {
                "Actualización Realizada"
            } else {
                "Error en Actualización"
            }
        } catch (e: NumberFormatException) {
            return "Error en Actualización: La edad no es un número válido"
        }
    }

    fun eliminarDatos(id: String): Int {
        try {
            val db = this.writableDatabase
            val resultado = db.delete("Usuario", "id=?", arrayOf(id))
            db.close()

            return resultado
        } catch (e: Exception) {
            e.printStackTrace()
            return 0
        }
    }

}
